@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.soap.jboss.com/AcmeDemo/")
package com.jboss.soap.service.acmedemo;
